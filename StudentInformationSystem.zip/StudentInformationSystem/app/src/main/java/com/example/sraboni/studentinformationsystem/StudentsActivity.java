package com.example.sraboni.studentinformationsystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class StudentsActivity extends AppCompatActivity {

    private Button theory;
    private Button sessional;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students);

        theory = findViewById(R.id.theoryId);
        sessional = findViewById(R.id.sessionalId);

        theory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1= new Intent(StudentsActivity.this,TheoryActivityTwo.class);
                startActivity(int1);
            }
        });

        sessional.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2= new Intent(StudentsActivity.this,SessionalActivityTwo.class);
                startActivity(int2);
            }
        });
    }
}
