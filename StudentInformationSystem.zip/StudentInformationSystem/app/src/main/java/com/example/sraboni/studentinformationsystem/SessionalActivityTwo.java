package com.example.sraboni.studentinformationsystem;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SessionalActivityTwo extends AppCompatActivity {

    private Button btn1,btn2,btn3,btn4;
    SQLiteDatabase db1;
    SQLiteDatabase db2;
    SQLiteDatabase db3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sessional_two);

        btn1 = findViewById(R.id.button3);
        btn2 = findViewById(R.id.button4);
        btn3 = findViewById(R.id.button5);
        btn4 = findViewById(R.id.button6);

        db1=openOrCreateDatabase("Course_Appraisal_Sessional", Context.MODE_PRIVATE, null);
        db2=openOrCreateDatabase("Book_List_Sessional", Context.MODE_PRIVATE, null);
        db3=openOrCreateDatabase("Mark_sheet_Sessional", Context.MODE_PRIVATE, null);

        btn1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Cursor c=db1.rawQuery("SELECT * FROM courseAppraisalSessional", null);
                if(c.getCount()==0)
                {
                    showMessage("Error", "No records found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext())
                {
                    buffer.append("Week-1: "+c.getString(0)+"\n");
                    buffer.append("Week-2: "+c.getString(1)+"\n");
                    buffer.append("Week-3: "+c.getString(2)+"\n");
                    buffer.append("Week-4: "+c.getString(3)+"\n");
                    buffer.append("Week-5: "+c.getString(4)+"\n");
                    buffer.append("Week-6: "+c.getString(5)+"\n");
                    buffer.append("Week-7: "+c.getString(6)+"\n");
                    buffer.append("Week-8: "+c.getString(7)+"\n\n");
                }
                showMessage("Course Appraisal", buffer.toString());
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Cursor c=db2.rawQuery("SELECT * FROM bookListSessional", null);
                if(c.getCount()==0)
                {
                    showMessage("Error", "No records found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext())
                {
                    buffer.append("Book-1: "+c.getString(0)+"\n");
                    buffer.append("Book-2: "+c.getString(1)+"\n");
                    buffer.append("Book-3: "+c.getString(2)+"\n");
                    buffer.append("Book-4: "+c.getString(3)+"\n");
                    buffer.append("Book-5: "+c.getString(4)+"\n\n");
                }
                showMessage("Book List", buffer.toString());
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showMessage("Grading System", "80% and above: A+ (4.0)\n75% to below 80%: A (3.75)\n70% to below 75%: A- (3.5)\n65% to below 70%: B+ (3.25)\n60% to below 65%: B (3.00)\n55% to below 60%: B- (2.75)\n50% to below 55%: C+ (2.50)\n45% to below 50%: C (2.25)\n40% to below 45%: D (2.00)\nBelow 40: F (0.00)\nIncomplete: I\nWithdrawal: W\nProject/Thesis Continuation: X");
                showMessage("Mark Distribution of Lab/Project based sessionals", "Lab test/Project : 40%\nQuiz: 20%\nViva voce: 10%\nAttendance: 10%\nHome assignment/Report: 10%\nClass Performance/Observation: 10%\nTotal: 100%");
                showMessage("Mark Distribution of Programming based sessionals", "Online-1 : 25%\nOnline-2: 25%\nViva voce: 10%\nAttendance: 10%\nObservation: 10%\nClass Performance: 20%\nTotal: 100%");
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Cursor c=db3.rawQuery("SELECT * FROM markSheetSessional", null);
                if(c.getCount()==0)
                {
                    showMessage("Error", "No records found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext())
                {
                    buffer.append("ID: "+c.getString(0)+"\n");
                    buffer.append("Name: "+c.getString(1)+"\n\n");
                    buffer.append("Lab Test Marks: "+c.getString(2)+"\n");
                    buffer.append("Quiz Marks: "+c.getString(3)+"\n");
                    buffer.append("Class Performance Marks: "+c.getString(4)+"\n");
                    buffer.append("Viva Voce Marks: "+c.getString(5)+"\n\n\n");
                }
                showMessage("Student Details", buffer.toString());
            }
        });
    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
