package com.example.sraboni.studentinformationsystem;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MarksSessional extends AppCompatActivity {

    EditText name,id,labmarks,quiz,classPer,viva;
    Button add,view,viewall,delete,modify;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marks_sessional);

        name=(EditText)findViewById(R.id.name);
        id=(EditText)findViewById(R.id.id);
        labmarks=(EditText)findViewById(R.id.labmark);
        quiz=(EditText)findViewById(R.id.quiz);
        classPer=(EditText)findViewById(R.id.classPerformance);
        viva=(EditText)findViewById(R.id.viva);
        add=(Button)findViewById(R.id.addbtn);
        view=(Button)findViewById(R.id.viewbtn);
        viewall=(Button)findViewById(R.id.viewallbtn);
        delete=(Button)findViewById(R.id.deletebtn);
        modify=(Button)findViewById(R.id.modifybtn);

        db=openOrCreateDatabase("Mark_sheet_Sessional", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS markSheetSessional (ID INTEGER,name VARCHAR,LabTest INTEGER,Quiz INTEGER,classPerformance INTEGER,VivaVoce INTEGER);");

        add.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if(id.getText().toString().trim().length()==0||
                        name.getText().toString().trim().length()==0||
                        labmarks.getText().toString().trim().length()==0||
                        quiz.getText().toString().trim().length()==0||
                        classPer.getText().toString().trim().length()==0||
                        viva.getText().toString().trim().length()==0)
                {
                    showMessage("Error", "Please enter all values");
                    return;
                }
                db.execSQL("INSERT INTO markSheetSessional VALUES('"+id.getText()+"','"+name.getText()+
                        "','"+labmarks.getText()+"','"+quiz.getText()+"','"+classPer.getText()+"','"+viva.getText()+"');");
                showMessage("Success", "Record added successfully");
                clearText();
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if(id.getText().toString().trim().length()==0)
                {
                    showMessage("Error", "Please enter Rollno");
                    return;
                }
                Cursor c=db.rawQuery("SELECT * FROM markSheetSessional WHERE ID='"+id.getText()+"'", null);
                if(c.moveToFirst())
                {
                    db.execSQL("DELETE FROM markSheetSessional WHERE ID='"+id.getText()+"'");
                    showMessage("Success", "Record Deleted");
                }
                else
                {
                    showMessage("Error", "Invalid Rollno");
                }
                clearText();
            }
        });
        modify.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if(id.getText().toString().trim().length()==0)
                {
                    showMessage("Error", "Please enter Rollno");
                    return;
                }
                Cursor c=db.rawQuery("SELECT * FROM markSheetSessional WHERE ID='"+id.getText()+"'", null);
                if(c.moveToFirst())
                {
                    db.execSQL("UPDATE markSheetSessional SET name='"+name.getText()+"',LabTest='"+labmarks.getText()+
                            "',Quiz='"+quiz.getText()+"',classPerformance='"+classPer.getText()+"',VivaVoce='"+viva.getText()+"' WHERE ID='"+id.getText()+"'");
                    showMessage("Success", "Record Modified");
                }
                else
                {
                    showMessage("Error", "Invalid Rollno");
                }
                clearText();
            }
        });
        view.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if(id.getText().toString().trim().length()==0)
                {
                    showMessage("Error", "Please enter Rollno");
                    return;
                }
                Cursor c=db.rawQuery("SELECT * FROM markSheetSessional WHERE ID='"+id.getText()+"'", null);
                if(c.moveToFirst())
                {
                    name.setText(c.getString(1));
                    labmarks.setText(c.getString(2));
                    quiz.setText(c.getString(3));
                    classPer.setText(c.getString(4));
                    viva.setText(c.getString(5));

                }
                else
                {
                    showMessage("Error", "Invalid Rollno");
                    clearText();
                }
            }
        });
        viewall.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Cursor c=db.rawQuery("SELECT * FROM markSheetSessional", null);
                if(c.getCount()==0)
                {
                    showMessage("Error", "No records found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext())
                {
                    buffer.append("ID: "+c.getString(0)+"\n");
                    buffer.append("Name: "+c.getString(1)+"\n\n");
                    buffer.append("Lab Test Marks: "+c.getString(2)+"\n");
                    buffer.append("Quiz Marks: "+c.getString(3)+"\n");
                    buffer.append("Class Performance Marks: "+c.getString(4)+"\n");
                    buffer.append("Viva Voce Marks: "+c.getString(5)+"\n\n\n");
                }
                showMessage("Student Details", buffer.toString());
            }
        });
    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText()
    {
        id.setText("");
        name.setText("");
        labmarks.setText("");
        quiz.setText("");
        classPer.setText("");
        viva.setText("");
        id.requestFocus();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.student_main, menu);
        return true;
    }
}
