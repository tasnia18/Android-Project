package com.example.sraboni.studentinformationsystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class StudentLoginActivity extends AppCompatActivity {

    private EditText courseCodeEditText,accessCodeEditText;
    private Button studentLogin;
    private TextView textView;
    private int counter=3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_login);

        courseCodeEditText = findViewById(R.id.courseCodeId);
        accessCodeEditText = findViewById(R.id.accessCodeId);
        studentLogin = findViewById(R.id.studentLoginId);
        textView = findViewById(R.id.textViewId);
        textView.setText("Number of attempts remaining : 3");

        studentLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String courseCode = courseCodeEditText.getText().toString();
                String accessCode = accessCodeEditText.getText().toString();

                if(courseCode.equals("CSE-322") && accessCode.equals("swe322"))
                {
                    Intent int1 = new Intent(StudentLoginActivity.this,StudentsActivity.class);
                    startActivity(int1);
                }

                else{
                    counter--;
                    textView.setText("\t\t             \tWrong Input!!\nNumber of attempts remaining : "+counter);
                    if(counter==0)
                    {
                        studentLogin.setEnabled(false);
                    }


                }
            }
        });
    }
}
