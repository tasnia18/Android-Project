package com.example.sraboni.studentinformationsystem;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class BookListActivity extends AppCompatActivity {

    EditText book1,book2,book3,book4,book5;
    Button add,view,delete,modify;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_list);

        book1=(EditText)findViewById(R.id.bk1);
        book2=(EditText)findViewById(R.id.bk2);
        book3=(EditText)findViewById(R.id.bk3);
        book4=(EditText)findViewById(R.id.bk4);
        book5=(EditText)findViewById(R.id.bk5);
        add=(Button)findViewById(R.id.addbtn);
        view=(Button)findViewById(R.id.viewbtn);
        delete=(Button)findViewById(R.id.deletebtn);
        modify=(Button)findViewById(R.id.modifybtn);

        db=openOrCreateDatabase("Book_List", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS bookList (book1 VARCHAR,book2 VARCHAR,book3 VARCHAR,book4 VARCHAR,book5 VARCHAR);");

        add.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if(book1.getText().toString().trim().length()==0)
                {
                    showMessage("Error", "Please name of the book");
                    return;
                }
                db.execSQL("INSERT INTO bookList VALUES('"+book1.getText()+"','"+book2.getText()+ "','"+book3.getText()+"','"+book4.getText()+"','"+book5.getText()+"');");
                showMessage("Success", "Record added successfully");
                clearText();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Cursor c=db.rawQuery("SELECT * FROM bookList", null);
                if(c.moveToFirst())
                {
                    db.execSQL("DELETE FROM bookList");
                    showMessage("Success", "Records Deleted");
                }
                else
                {
                    showMessage("Error", "Records could not be deleted!");
                }
                clearText();
            }
        });

        modify.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if(book1.getText().toString().trim().length()==0)
                {
                    showMessage("Error", "Please enter name of the book");
                    return;
                }

                Cursor c=db.rawQuery("SELECT * FROM bookList", null);
                if(c.moveToFirst())
                {
                    db.execSQL("UPDATE bookList SET book1='"+book1.getText()+"',book2='"+book2.getText()+
                            "',book3='"+book3.getText()+"',book4='"+book4.getText()+"',book5='"+book5.getText()+"'");
                    showMessage("Success", "Record Modified");
                }
                else
                {
                    showMessage("Error", "Records could not be modified!");
                }
                clearText();
            }
        });

        view.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Cursor c=db.rawQuery("SELECT * FROM bookList", null);
                if(c.getCount()==0)
                {
                    showMessage("Error", "No records found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext())
                {
                    buffer.append("Book-1: "+c.getString(0)+"\n");
                    buffer.append("Book-2: "+c.getString(1)+"\n");
                    buffer.append("Book-3: "+c.getString(2)+"\n");
                    buffer.append("Book-4: "+c.getString(3)+"\n");
                    buffer.append("Book-5: "+c.getString(4)+"\n\n");
                }
                showMessage("Book List", buffer.toString());
            }
        });
    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText()
    {
        book1.setText("");
        book2.setText("");
        book3.setText("");
        book4.setText("");
        book5.setText("");
        book1.requestFocus();
    }
}
