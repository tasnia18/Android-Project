package com.example.sraboni.studentinformationsystem;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CourseAppraisalActivity extends AppCompatActivity {

    EditText week1,week2,week3,week4,week5,week6,week7,week8;
    Button add,view,delete,modify;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_appraisal);

        week1=(EditText)findViewById(R.id.wk1);
        week2=(EditText)findViewById(R.id.wk2);
        week3=(EditText)findViewById(R.id.wk3);
        week4=(EditText)findViewById(R.id.wk4);
        week5=(EditText)findViewById(R.id.wk5);
        week6=(EditText)findViewById(R.id.wk6);
        week7=(EditText)findViewById(R.id.wk7);
        week8=(EditText)findViewById(R.id.wk8);
        add=(Button)findViewById(R.id.addbtn);
        view=(Button)findViewById(R.id.viewbtn);
        delete=(Button)findViewById(R.id.deletebtn);
        modify=(Button)findViewById(R.id.modifybtn);

        db=openOrCreateDatabase("Course_Appraisal", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS courseAppraisal (week1 VARCHAR,week2 VARCHAR,week3 VARCHAR,week4 VARCHAR,week5 VARCHAR,week6 VARCHAR,week7 VARCHAR,week8 VARCHAR);");

        add.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if(week1.getText().toString().trim().length()==0||
                        week2.getText().toString().trim().length()==0||
                        week3.getText().toString().trim().length()==0||
                        week4.getText().toString().trim().length()==0||
                        week5.getText().toString().trim().length()==0||
                        week6.getText().toString().trim().length()==0||
                        week7.getText().toString().trim().length()==0||
                        week8.getText().toString().trim().length()==0)
                {
                    showMessage("Error", "Please enter all values");
                    return;
                }
                db.execSQL("INSERT INTO courseAppraisal VALUES('"+week1.getText()+"','"+week2.getText()+
                        "','"+week3.getText()+"','"+week4.getText()+"','"+week5.getText()+"','"+week6.getText()+"','"+week7.getText()+"','"+week8.getText()+"');");
                showMessage("Success", "Record added successfully");
                clearText();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Cursor c=db.rawQuery("SELECT * FROM courseAppraisal", null);
                if(c.moveToFirst())
                {
                    db.execSQL("DELETE FROM courseAppraisal");
                    showMessage("Success", "Records Deleted");
                }
                else
                {
                    showMessage("Error", "Records could not be deleted!");
                }
                clearText();
            }
        });

        modify.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if((week1.getText().toString().trim().length()==0)||(week2.getText().toString().trim().length()==0)||(week3.getText().toString().trim().length()==0)||(week4.getText().toString().trim().length()==0)||(week5.getText().toString().trim().length()==0)||(week6.getText().toString().trim().length()==0)||(week7.getText().toString().trim().length()==0)||(week8.getText().toString().trim().length()==0))
                {
                    showMessage("Error", "Please enter Records");
                    return;
                }

                Cursor c=db.rawQuery("SELECT * FROM courseAppraisal", null);
                if(c.moveToFirst())
                {
                    db.execSQL("UPDATE courseAppraisal SET week1='"+week1.getText()+"',week2='"+week2.getText()+
                            "',week3='"+week3.getText()+"',week4='"+week4.getText()+"',week5='"+week5.getText()+"',week6='"+week6.getText()+"',week7='"+week7.getText()+"',week8='"+week8.getText()+"'");
                    showMessage("Success", "Record Modified");
                }
                else
                {
                    showMessage("Error", "Records could not be modified!");
                }
                clearText();
            }
        });

        view.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Cursor c=db.rawQuery("SELECT * FROM courseAppraisal", null);
                if(c.getCount()==0)
                {
                    showMessage("Error", "No records found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext())
                {
                    buffer.append("Week-1: "+c.getString(0)+"\n");
                    buffer.append("Week-2: "+c.getString(1)+"\n");
                    buffer.append("Week-3: "+c.getString(2)+"\n");
                    buffer.append("Week-4: "+c.getString(3)+"\n");
                    buffer.append("Week-5: "+c.getString(4)+"\n");
                    buffer.append("Week-6: "+c.getString(5)+"\n");
                    buffer.append("Week-7: "+c.getString(6)+"\n");
                    buffer.append("Week-8: "+c.getString(7)+"\n\n");
                }
                showMessage("Course Appraisal", buffer.toString());
            }
        });
    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText()
    {
        week1.setText("");
        week2.setText("");
        week3.setText("");
        week4.setText("");
        week5.setText("");
        week6.setText("");
        week7.setText("");
        week8.setText("");
        week1.requestFocus();
    }
}
